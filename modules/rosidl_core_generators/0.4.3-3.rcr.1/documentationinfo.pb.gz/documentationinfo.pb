�
"
rosidl_core_generatorsdefs.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rosidl_core_generators/rules.bzl", line 427, column 7, in <toplevel>
		} | py_common.API_ATTRS,
Error: unsupported binary operation: dict | FakeDeepStructure�
#
rosidl_core_generators	rules.bzl*�ModuleInfo request error: invalid argument: Traceback (most recent call last):
	File "external/rosidl_core_generators/rules.bzl", line 427, column 7, in <toplevel>
		} | py_common.API_ATTRS,
Error: unsupported binary operation: dict | FakeDeepStructure 